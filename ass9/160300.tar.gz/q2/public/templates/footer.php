<div style="position:fixed; bottom:0; right:0;"><a href="index.php">Another Registeration</a></div>
</body>
</html>
